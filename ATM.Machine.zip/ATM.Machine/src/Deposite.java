import com.sun.nio.sctp.SctpChannel;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.*;
import java.util.*;
import javax.swing.*;

public class Deposite {
    Scanner SD = new Scanner(System.in);

    public void DepositeAmount() throws SQLException {

            Database d = new Database();              //Import database class
            DepositMoney DM = new DepositMoney();     //Import DepositMoney Class

            System.out.println("\n");
            System.out.println("Please Enter Your Account Number: ");

            int AN = SD.nextInt(); /////database
        d.CreateConnection();
        Connection con = d.getConnector();

        PreparedStatement stat = con.prepareStatement("SELECT * from user WHERE account_no = ?");
        stat.setInt(1, AN);
        ResultSet rs = stat.executeQuery();

        if (rs.next()) {
            String cname = rs.getString(2);
            System.out.println("Welcome Back:  " + cname);
            DM.DepositCash(AN, cname);

        }else{
            System.out.println("Account not found");
             }



        //bill
    }
}

