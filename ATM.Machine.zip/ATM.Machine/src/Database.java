import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Database {
    // transaction type "withdraw, deposit, bill"
    //account type " saving, current"
    String host = "jdbc:mysql://localhost:3306/dbatm";
    String uName = "root";
    String uPass = "AA14AA14";
    Connection con;

    void CreateConnection(){
        try {

            con = DriverManager.getConnection(host, uName, uPass);



        } catch (SQLException err) {
            System.out.println(err.getMessage());
        }

    }
    Connection getConnector(){
        return this.con;
    }
    }
