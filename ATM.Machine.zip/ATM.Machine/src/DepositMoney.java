import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

public class DepositMoney extends Deposite{
    Scanner scan = new Scanner(System.in);


public void DepositCash(int AN, String cname) throws SQLException {


    String type = "deposit";
    int m = 1;

    Database d = new Database();
    d.CreateConnection();
    Connection con = d.getConnector();


        System.out.println("Deposit Money to: ");
        System.out.println("1. Savings " + "\n" + "2. Current");
        int typ = scan.nextInt();
        int pre_amount_savings = 0;
        int pre_amount_current = 0;

///////////////////////////////////////////     ON SAVINGS       //////////////////////////////////////////////////////////////////////////////////////////////////////////

        if (typ == 1){                  // on Savings


do {

    System.out.println("You are on savings account");
    System.out.print("Enter amount you want to deposit: ");
    boolean valid = false;
    int amount;


    do{
        amount = scan.nextInt();
        if(amount > 99 & amount % 100 == 0) {
            valid = true;
        } else {
            System.out.println("Please deposit more than 99 and in hundreds of thousands");
        }
    }while (! valid);




    PreparedStatement astat = con.prepareStatement("SELECT * from user WHERE account_no = ?");
    astat.setInt(1, AN);
    ResultSet ars = astat.executeQuery();




    if (ars.next()) {
        System.out.println("Previous amount:   " + ars.getInt(5));
        pre_amount_savings = ars.getInt(5);


    } else {
        System.out.println("Account not found");
    }


//////////////////////////////         UPDATE USER         //////////////////////////////////////////////////////

    int new_amount = pre_amount_savings + amount;
    //sql
    PreparedStatement stat = con.prepareStatement("UPDATE user SET saving_balance = ? WHERE account_no = ?");
    stat.setInt(1, new_amount);
    stat.setInt(2, AN);
    int rs = stat.executeUpdate();

    System.out.println("Deposit successful  ");

///////////////////////////////////////////////////////////////////////////////////////////////////////////////



//////////////////////////////         INSERT INTO ACCOUNTS      ///////////////////////////////////////////////
    String Dtype = "Saving";
    String Wtype = "Deposit";

    PreparedStatement ustat = con.prepareStatement("INSERT INTO accounts (amount, transaction_type, account_type, account_no) VALUE (?,?,?,?)");
    ustat.setInt(1, amount);
    ustat.setString(2, "Deposit");
    ustat.setString(3, "Savings");
    ustat.setInt(4, AN);
    int rsa = ustat.executeUpdate();
    GenerateBill GB = new GenerateBill();
    GB.DepBill(cname, amount, Dtype, Wtype, AN);
    System.out.println("Deposit More? press ( 2 )");
    m = 1;
    m = scan.nextInt();

///////////////////////////////////////////////////////////////////////////////////////////////////////////////


}while (m ==2);



//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////




        }else if (typ == 2){       //on current
            do {

                System.out.println("You are on current account");
                System.out.print("Enter amount you want to deposit: ");
                boolean valid = false;
                int amount;


                do{
                    amount = scan.nextInt();
                    if(amount > 99 & amount % 100 == 0) {
                        valid = true;
                    } else {
                        System.out.println("Please deposit more than 99 and in hundreds of thousands");
                    }
                }while (! valid);




                PreparedStatement astat = con.prepareStatement("SELECT * from user WHERE account_no = ?");
                astat.setInt(1, AN);
                ResultSet ars = astat.executeQuery();




                if (ars.next()) {
                    System.out.println("Previous amount:   " + ars.getInt(4));
                    pre_amount_current = ars.getInt(4);


                } else {
                    System.out.println("Account not found");
                }

                int new_amount = pre_amount_current + amount;



//////////////////////////////         UPDATE USER          ///////////////////////////////////////////////////

                PreparedStatement stat = con.prepareStatement("UPDATE user SET current_balance = ? WHERE account_no = ?");
                stat.setInt(1, new_amount);
                stat.setInt(2, AN);
                int rs = stat.executeUpdate();

                System.out.println("Deposit successful  ");

///////////////////////////////////////////////////////////////////////////////////////////////////////////////




//////////////////////////////         INSERT INTO ACCOUNTS      //////////////////////////////////////////////////

                PreparedStatement ustat = con.prepareStatement("INSERT INTO accounts (amount, transaction_type, account_type, account_no) VALUE (?,?,?,?)");
                ustat.setInt(1, amount);
                ustat.setString(2, "Deposit");
                ustat.setString(3, "Current");
                ustat.setInt(4, AN);
                int rsa = ustat.executeUpdate();


                String Dtype = "Current";
                String Wtype = "Deposit";
                GenerateBill GB = new GenerateBill();
                GB.DepBill(cname, amount, Dtype, Wtype,AN);


                System.out.println("Deposit More? press ( 2 )");
                m = 1;
                m = scan.nextInt();

///////////////////////////////////////////////////////////////////////////////////////////////////////////////

            }while (m ==2);

        }else {
            System.out.println("Account type not found!! ");
        }

        //previous
}
}
