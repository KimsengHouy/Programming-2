import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Card {
//    public JFrame frame;
//    public static JLabel passlabel;
//    public static JPasswordField Pin;
//    public static JButton button;
//    public static JLabel success;
    Scanner SC = new Scanner(System.in);

    public void InsertCard() throws SQLException {

//        JFrame frame = new JFrame();
//        frame.setSize(600,600);
//        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        frame.setVisible(true);
//
//        JPanel panel = new JPanel();
//        frame.add(panel);
//        panel.setLayout(null);
//
//        passlabel = new JLabel("Enter pin ");
//        passlabel.setBounds(10,20, 80, 25);
//        panel.add(passlabel);
//
//        Pin = new JPasswordField();
//        Pin.setBounds(100, 20, 165, 25);
//        panel.add(Pin);
//
//        button = new JButton("Confirm");
//        button.setBounds(10, 50, 80, 25);
//        button.addActionListener(new Card());
//        panel.add(button);
//
//        success = new JLabel();
//        success.setBounds(10, 80, 80, 25);
//        panel.add(success);
//
//        frame.setVisible(true);
//
//
//
        System.out.println("please Enter Pin");
        int Pin = SC.nextInt();
        System.out.println();

        ////////////////////////////////////////////

        Database d = new Database();
        d.CreateConnection();
        Connection con = d.getConnector();

        PreparedStatement stat = con.prepareStatement("SELECT * from user WHERE password = ?");
        stat.setInt(1, Pin);
        ResultSet rs = stat.executeQuery();

        ////////////////////////////////////////////

        if (rs.next()){
            System.out.println("Access Granted");
            System.out.println("Welcome Back!! "+ rs.getString(2));
            String cname = rs.getString(2);
            System.out.println();
            Withdraw W = new Withdraw();
            W.Choose(Pin,cname);

        }else{
            System.out.println("Access Denied");
        }

    }

    public void RemoveCard(){

    }

    public void Card (int number) {this.number = number;}

    public int getNumber() {return number;}

    private int number;

//    @Override
//    public void actionPerformed(ActionEvent e) {
//        String password = Pin.getText();
//        if (password.equals("akeef")){
//            success.setText("Log in successful");
//        }else System.out.println("Wrong Password");
//
//    }
}
