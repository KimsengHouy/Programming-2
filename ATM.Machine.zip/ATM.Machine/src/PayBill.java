import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

public class PayBill {
Scanner SP = new Scanner(System.in);




    public void ScanBill(){

        System.out.println("Bill Scan Complete");
    }



    public void PaytheBill() throws SQLException {
        InsertAmount IA = new InsertAmount();
        System.out.println("Please enter pin: ");


        int Pin = SP.nextInt();
        System.out.println();

        ////////////////////////////////////////////

        Database d = new Database();
        d.CreateConnection();
        Connection con = d.getConnector();

        PreparedStatement stat = con.prepareStatement("SELECT * from user WHERE password = ?");
        stat.setInt(1, Pin);
        ResultSet rs = stat.executeQuery();

        ////////////////////////////////////////////

        if (rs.next()){
            System.out.println("Access Granted");
            System.out.println("Welcome Back!! "+ rs.getString(2));
            String cname = rs.getString(2);
            System.out.println();
            IA.InsertMoneyBill(Pin,cname);

        }else{
            System.out.println("Access Denied");
        }




        /////////// generate bill
    }
}
