import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfWriter;

import javax.swing.*;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.*;

public class Reciept extends PayBill{
    Document document = new Document();

    public void DepBill(String cname, int amount, String Dtype, String Wtype){
        try{
            PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream("Invoice.pdf"));
            document.open();
            Font f1 = new Font(Font.FontFamily.TIMES_ROMAN, 40, Font.BOLD, BaseColor.BLACK);
            document.add(new Paragraph(new Date().toString()));
            document.add(new Paragraph("............................................................................................................................................................"));
            Paragraph p = new Paragraph("ATM TRANSACTION ",f1);
            p.setAlignment(Element.ALIGN_CENTER);
            document.add(p);
            document.add(new Paragraph("............................................................................................................................................................"));
            document.add(new Paragraph("\n"));
            document.add(new Paragraph("                       TERMINAL#                                                                    " + "012345"));
            document.add(new Paragraph("                       BANK Name#                                                                   " + "KBank"));
            document.add(new Paragraph("                       Transaction                                                                     " + Wtype));
            document.add(new Paragraph("                       Account Type                                                                 " + Dtype));
            document.add(new Paragraph("\n"));
            document.add(new Paragraph("                       Card Number                                                               " + "XXXX XXXX XXXX XXX"));
            document.add(new Paragraph("\n"));
            document.add(new Paragraph("                       CUSTOMER NAME                                                          " + cname));
            document.add(new Paragraph("\n"));
            document.add(new Paragraph("                       PAID AMOUNT                                                     " + "$" + amount));
            document.add(new Paragraph("                       TERMINAL FEE                                                                    " + "$0"));
            document.add(new Paragraph("\n"));
            document.add(new Paragraph("............................................................................................................................................................"));
            document.add(new Paragraph("............................................................................................................................................................"));

            System.out.println("Bill generated");

            document.close();
            writer.close();
        }
        catch (FileNotFoundException | DocumentException e){
            e.printStackTrace();
        }



    }

}
