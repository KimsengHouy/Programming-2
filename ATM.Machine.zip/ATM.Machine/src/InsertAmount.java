import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

public class InsertAmount extends PayBill{

    Scanner SP = new Scanner(System.in);

    public void InsertMoneyBill(int Pin, String cname) throws SQLException {
        int m = 1;
        int pre_amount_savings = 0;
        int pre_amount_current = 0;

        Database d = new Database();
        d.CreateConnection();
        Connection con = d.getConnector();

        System.out.println("Choose a language");
        System.out.println("1. English \n" + "2. Thai");
        int lan = SP.nextInt();

        if (lan == 1) {

            System.out.println("Select options you want to pay for: ");
            System.out.println("1. Water Bill");
            System.out.println("2. Electric Bill");
            int op = SP.nextInt();

            ////////////////////////////////////////////////////////////////////





            switch (op) {
                case 1:
                    System.out.println("Choose an method to pay water bill");
                    System.out.println("1. Saving account\n" + "2. Current account");
                    int a = SP.nextInt();
                    if (a == 1 ) {

                        do {

                            System.out.println("You are on savings account");
                            System.out.print("Enter amount you want to deposit: ");
                            boolean valid = false;
                            int amount;


                            do {
                                amount = SP.nextInt();
                                if (amount > 99) {
                                    valid = true;
                                } else {
                                    System.out.println("Please deposit more than 99");
                                }
                            } while (!valid);


                            PreparedStatement astat = con.prepareStatement("SELECT * from user WHERE password = ?");
                            astat.setInt(1, Pin);
                            ResultSet ars = astat.executeQuery();


                            if (ars.next()) {
                                System.out.println("Previous amount:   " + ars.getInt(5));
                                pre_amount_savings = ars.getInt(5);


                            } else {
                                System.out.println("Account not found");
                            }


//////////////////////////////         UPDATE USER         //////////////////////////////////////////////////////

                            int new_amount = pre_amount_savings - amount;
                            //sql
                            PreparedStatement stat = con.prepareStatement("UPDATE user SET saving_balance = ? WHERE password = ?");
                            stat.setInt(1, new_amount);
                            stat.setInt(2, Pin);
                            int rs = stat.executeUpdate();

                            System.out.println(" Paid successfully  ");

///////////////////////////////////////////////////////////////////////////////////////////////////////////////


//////////////////////////////         INSERT INTO ACCOUNTS      ///////////////////////////////////////////////

                            PreparedStatement ustat = con.prepareStatement("INSERT INTO accounts (amount, transaction_type, account_type, account_no) VALUE (?,?,?,?)");
                            ustat.setInt(1, amount);
                            ustat.setString(2, "Pay (Water Bill)");
                            ustat.setString(3, "Savings");
                            ustat.setInt(4, ars.getInt(3));
                            int rsa = ustat.executeUpdate();

                            String Dtype = "Saving";
                            String Wtype = "Pay (Water Bill)";
                            Reciept R = new Reciept();
                            R.DepBill(cname, amount, Dtype, Wtype);

                            System.out.println("Deposit More? press ( 2 )");
                            m = 1;
                            m = SP.nextInt();

///////////////////////////////////////////////////////////////////////////////////////////////////////////////


                        } while (m == 2);
                    }else if (a == 2){


                        do {

                            System.out.println("You are on current account");
                            System.out.print("Enter amount you want to deposit: ");
                            boolean valid = false;
                            int amount;


                            do {
                                amount = SP.nextInt();
                                if (amount > 99) {
                                    valid = true;
                                } else {
                                    System.out.println("Please deposit more than 99");
                                }
                            } while (!valid);


                            PreparedStatement astat = con.prepareStatement("SELECT * from user WHERE password = ?");
                            astat.setInt(1, Pin);
                            ResultSet ars = astat.executeQuery();


                            if (ars.next()) {
                                System.out.println("Previous amount:   " + ars.getInt(4));
                                pre_amount_current = ars.getInt(4);


                            } else {
                                System.out.println("Account not found");
                            }


//////////////////////////////         UPDATE USER         //////////////////////////////////////////////////////

                            int new_amount = amount - pre_amount_current;
                            //sql
                            PreparedStatement stat = con.prepareStatement("UPDATE user SET current_balance = ? WHERE password = ?");
                            stat.setInt(1, new_amount);
                            stat.setInt(2, Pin);
                            int rs = stat.executeUpdate();

                            System.out.println("Deposit successful  ");

///////////////////////////////////////////////////////////////////////////////////////////////////////////////


//////////////////////////////         INSERT INTO ACCOUNTS      ///////////////////////////////////////////////

                            PreparedStatement ustat = con.prepareStatement("INSERT INTO accounts (amount, transaction_type, account_type, account_no) VALUE (?,?,?,?)");
                            ustat.setInt(1, amount);
                            ustat.setString(2, "Pay (Water Bill)");
                            ustat.setString(3, "Current");
                            ustat.setInt(4, ars.getInt(3));
                            int rsa = ustat.executeUpdate();

                            String Dtype = "Current";
                            String Wtype = "Pay (Water Bill)";
                            Reciept R = new Reciept();
                            R.DepBill(cname, amount, Dtype, Wtype);


                            System.out.println("Deposit More? press ( 2 )");
                            m = 1;
                            m = SP.nextInt();

///////////////////////////////////////////////////////////////////////////////////////////////////////////////


                        } while (m == 2);


                    }
                    break;
                case 2:


                    System.out.println("Choose an method to pay Electric bill");
                    System.out.println("1. Saving account \n" + "2. Current account");
                    int b = SP.nextInt();
                    if (b == 1 ) {

                        do {

                            System.out.println("You are on savings account");
                            System.out.print("Enter amount you want to deposit: ");
                            boolean valid = false;
                            int amount;


                            do {
                                amount = SP.nextInt();
                                if (amount > 99) {
                                    valid = true;
                                } else {
                                    System.out.println("Please deposit more than 99");
                                }
                            } while (!valid);


                            PreparedStatement astat = con.prepareStatement("SELECT * from user WHERE password = ?");
                            astat.setInt(1, Pin);
                            ResultSet ars = astat.executeQuery();


                            if (ars.next()) {
                                System.out.println("Previous amount:   " + ars.getInt(5));
                                pre_amount_savings = ars.getInt(5);


                            } else {
                                System.out.println("Account not found");
                            }


//////////////////////////////         UPDATE USER         //////////////////////////////////////////////////////

                            int new_amount = amount - pre_amount_savings;
                            //sql
                            PreparedStatement stat = con.prepareStatement("UPDATE user SET saving_balance = ? WHERE password = ?");
                            stat.setInt(1, new_amount);
                            stat.setInt(2, Pin);
                            int rs = stat.executeUpdate();

                            System.out.println("Deposit successful  ");

///////////////////////////////////////////////////////////////////////////////////////////////////////////////


//////////////////////////////         INSERT INTO ACCOUNTS      ///////////////////////////////////////////////

                            PreparedStatement ustat = con.prepareStatement("INSERT INTO accounts (amount, transaction_type, account_type, account_no) VALUE (?,?,?,?)");
                            ustat.setInt(1, amount);
                            ustat.setString(2, "Pay (Electric Bill)");
                            ustat.setString(3, "Savings");
                            ustat.setInt(4, ars.getInt(3));
                            int rsa = ustat.executeUpdate();

                            String Dtype = "Saving";
                            String Wtype = "Pay (Electric Bill)";
                            Reciept R = new Reciept();
                            R.DepBill(cname, amount, Dtype, Wtype);


                            System.out.println("Deposit More? press ( 2 )");
                            m = 1;
                            m = SP.nextInt();

///////////////////////////////////////////////////////////////////////////////////////////////////////////////


                        } while (m == 2);
                        break;

                    }else if (b == 2){


                        do {

                            System.out.println("You are on current account");
                            System.out.print("Enter amount you want to deposit: ");
                            boolean valid = false;
                            int amount;


                            do {
                                amount = SP.nextInt();
                                if (amount > 99) {
                                    valid = true;
                                } else {
                                    System.out.println("Please deposit more than 99");
                                }
                            } while (!valid);


                            PreparedStatement astat = con.prepareStatement("SELECT * from user WHERE password = ?");
                            astat.setInt(1, Pin);
                            ResultSet ars = astat.executeQuery();


                            if (ars.next()) {
                                System.out.println("Previous amount:   " + ars.getInt(4));
                                pre_amount_current = ars.getInt(4);


                            } else {
                                System.out.println("Account not found");
                            }


//////////////////////////////         UPDATE USER         //////////////////////////////////////////////////////

                            int new_amount = pre_amount_current - amount;
                            //sql
                            PreparedStatement stat = con.prepareStatement("UPDATE user SET current_balance = ? WHERE password = ?");
                            stat.setInt(1, new_amount);
                            stat.setInt(2, Pin);
                            int rs = stat.executeUpdate();

                            System.out.println("Deposit successful  ");

///////////////////////////////////////////////////////////////////////////////////////////////////////////////


//////////////////////////////         INSERT INTO ACCOUNTS      ///////////////////////////////////////////////

                            PreparedStatement ustat = con.prepareStatement("INSERT INTO accounts (amount, transaction_type, account_type, account_no) VALUE (?,?,?,?)");
                            ustat.setInt(1, amount);
                            ustat.setString(2, "Pay (Electric Bill)");
                            ustat.setString(3, "Current");
                            ustat.setInt(4, ars.getInt(3));
                            int rsa = ustat.executeUpdate();

                            String Dtype = "Current";
                            String Wtype = "Pay (Electric Bill)";
                            Reciept R = new Reciept();
                            R.DepBill(cname, amount, Dtype, Wtype);


                            System.out.println("Deposit More? press ( 2 )");
                            m = 1;
                            m = SP.nextInt();

///////////////////////////////////////////////////////////////////////////////////////////////////////////////


                        } while (m == 2);


                    }

            }
        } else if (lan == 2) {
            System.out.println("เลือกตัวเลือกที่คุณต้องการจ่าย: ");
            System.out.println("1. ค่าน้ำประปา");
            System.out.println("2. บิลไฟฟ้า");
            int op = SP.nextInt();

            switch (op) {
                case 1:
                    System.out.println("ใส่จำนวนเงิน: ");
                    double Dep = SP.nextDouble();
                    System.out.println("ธุรกรรมของคุณเสร็จสมบูรณ์, คุณจ่าย ฿" + Dep + " สำหรับน้ำ");
                    break;
                case 2:
                    System.out.println("ใส่จำนวนเงิน: ");
                    double Dep2 = SP.nextDouble();
                    System.out.println("ธุรกรรมของคุณเสร็จสมบูรณ์, คุณจ่าย ฿" + Dep2 + " สำหรับแสง");
                    break;
            }
        }
    }
    public void PayWater(){

    }
    public void PayElectric(){

    }
}

