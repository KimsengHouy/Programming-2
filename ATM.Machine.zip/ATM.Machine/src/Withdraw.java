import javax.swing.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

public class Withdraw  extends Card{ //saving and current in array
    Scanner SW = new Scanner(System.in);
int m = 1;
    String[] WithdrawType = {"", "Current", "Savings"};
    int pre_amount_savings = 0;
    int pre_amount_current = 0;


    public void Choose(int Pin, String cname) throws SQLException {



        System.out.println("Which Account");
        System.out.println("1) Current");
        System.out.println("2) Savings");
        System.out.println("Choose an option; ");
        int op = SW.nextInt();



        Database d = new Database();
        d.CreateConnection();
        Connection con = d.getConnector();

        if (op == 1) {
do {
            System.out.println("your on " + WithdrawType[op]);
            System.out.println("Enter the amount to withdraw: ");

            boolean valid = false;
            int amount;


            do {
                amount = SW.nextInt();
                if (amount > 99 & amount % 100 == 0) {
                    valid = true;
                } else {
                    System.out.println("Please Withdraw more than 99 and in hundreds or thousands");
                }
            } while (!valid);


            PreparedStatement astat = con.prepareStatement("SELECT * from user WHERE password = ?");
            astat.setInt(1, Pin);
            ResultSet ars = astat.executeQuery();

            if (ars.next()) {
                System.out.println("Previous amount:   " + ars.getInt(4));
                pre_amount_current = ars.getInt(4);


            } else {
                System.out.println("Account not found");
            }

            //////////////////////////////         UPDATE USER         //////////////////////////////////////////////////////

            int new_amount = pre_amount_current - amount;
            //sql
            PreparedStatement stat = con.prepareStatement("UPDATE user SET current_balance = ? WHERE password = ?");
            stat.setInt(1, new_amount);
            stat.setInt(2, Pin);
            int rs = stat.executeUpdate();
    System.out.println();
            System.out.println("Withdraw successful  ");
    System.out.println();

///////////////////////////////////////////////////////////////////////////////////////////////////////////////

//////////////////////////////         INSERT INTO ACCOUNTS      ///////////////////////////////////////////////

            PreparedStatement ustat = con.prepareStatement("INSERT INTO accounts (amount, transaction_type, account_type, account_no) VALUE (?,?,?,?)");
            ustat.setInt(1, amount);
            ustat.setString(2, "Withdraw");
            ustat.setString(3, "Current");
            ustat.setInt(4, ars.getInt(3));
            int rsa = ustat.executeUpdate();

    String Dtype = "Current";
    String Wtype = "Withdraw";
    WithdrawBill WB = new WithdrawBill();
    WB.DepBill(cname, amount, Dtype, Wtype);

            System.out.println("Deposit More? press ( 2 )");
            m = 1;
            m = SW.nextInt();
        }while (m == 2);

///////////////////////////////////////////////////////////////////////////////////////////////////////////////








        } else if (op == 2) {

do {
    System.out.println("your on " + WithdrawType[op]);
    System.out.println("Enter the amount to withdraw: ");

    boolean valid = false;
    int amount;


    do {
        amount = SW.nextInt();
        if (amount > 99 & amount % 100 == 0) {
            valid = true;
        } else {
            System.out.println("Please Withdraw more than 99 and in hundreds or thousands");
        }
    } while (!valid);


    PreparedStatement astat = con.prepareStatement("SELECT * from user WHERE password = ?");
    astat.setInt(1, Pin);
    ResultSet ars = astat.executeQuery();

    if (ars.next()) {
        System.out.println("Previous amount:   " + ars.getInt(5));
        pre_amount_savings = ars.getInt(5);


    } else {
        System.out.println("Account not found");
    }

    //////////////////////////////         UPDATE USER         //////////////////////////////////////////////////////

    int new_amount = pre_amount_savings - amount;
    //sql
    PreparedStatement stat = con.prepareStatement("UPDATE user SET saving_balance = ? WHERE password = ?");
    stat.setInt(1, new_amount);
    stat.setInt(2, Pin);
    int rs = stat.executeUpdate();

    System.out.println("Withdraw successful  ");
    System.out.println();

///////////////////////////////////////////////////////////////////////////////////////////////////////////////

//////////////////////////////         INSERT INTO ACCOUNTS      ///////////////////////////////////////////////

    PreparedStatement ustat = con.prepareStatement("INSERT INTO accounts (amount, transaction_type, account_type, account_no) VALUE (?,?,?,?)");
    ustat.setInt(1, amount);
    ustat.setString(2, "Withdraw");
    ustat.setString(3, "Savings");
    ustat.setInt(4, ars.getInt(3));
    int rsa = ustat.executeUpdate();

    String Dtype = "Savings";
    String Wtype = "Withdraw";
    WithdrawBill WB = new WithdrawBill();
    WB.DepBill(cname, amount, Dtype, Wtype);

    System.out.println("Deposit More? press ( 2 )");
    m = 1;
    m = SW.nextInt();
}while (m == 2);

///////////////////////////////////////////////////////////////////////////////////////////////////////////////




        }
        }

}
