import javax.swing.*;
import java.awt.*;
import java.util.*;
import javax.swing.*;

public class AtmMachine  {




    public static void main(String[] args) {
        int wh = 0;


        while (wh < 10) {   //maximum 10 times
            try {

                AtmMachine atm = new AtmMachine();
                Scanner ScanAtm = new Scanner(System.in);
                System.out.println("Welcome Back!!");
                System.out.println("\n");
                System.out.println("Select the transaction");
                System.out.println("");
                System.out.println("a = Deposit Amount");
                System.out.println("b = Pay Bill");
                System.out.println("c = Card");
                char transaction = ScanAtm.next().charAt(0);

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////


//////////////////////////      DEPOSIT AMOUNT      /////////////////////////////////////////////////////////////////

                if (transaction == 'a') {                     //Deposit
                    System.out.println();
                    Deposite D = new Deposite();
                    System.out.println("Deposit Amount");
                    D.DepositeAmount();


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////


//////////////////////////        PAY BILL        /////////////////////////////////////////////////////////////////


                } else if (transaction == 'b') {              //Bill
                    System.out.println();
                    PayBill PB = new PayBill();
                    System.out.println("Pay Bill");
                    PB.PaytheBill();


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////


//////////////////////////      WITHDRAW AMOUNT      /////////////////////////////////////////////////////////////////


                } else if (transaction == 'c') {              //Card
                    System.out.println();
                    System.out.println("card");
                    Card card = new Card();
                    card.InsertCard();


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////


                }


        }catch(Exception e){
            System.out.println("Exception notified");
        }
    }
    }
}


